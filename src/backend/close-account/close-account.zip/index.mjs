import mysql from 'mysql';

export const handler = async (event) => {
    console.log('Creating MySQL pool...');
    var pool = mysql.createPool({
        host: "auctionhousedb.chyqe6cmmf08.us-east-1.rds.amazonaws.com",
        user: "auctionadmin",
        password: "sp6dO9CPdNecytAhsnQm",
        database: "auctionhouse"
    });

    const username = event.username;

    return new Promise((resolve, reject) => {
        // Type check all args
        if (typeof username !== 'string') {
            const error = new TypeError('Invalid username parameter. Expected a string.');
            console.error(error);
            return reject(error);
        }

        // Check if username already exists
        const checkQuery = `SELECT status FROM ${mysql.escapeId(accountType)} WHERE username = ${mysql.escape(username)}`;
        console.log('Executing check query:', checkQuery);
        pool.query(checkQuery, (checkError, checkResults) => {
            if (checkError) {
                console.error('Check query error:', checkError);
                return reject(checkError);
            }

            if (checkResults.length > 0) {
                // make sure account status is not already closed
                const status = checkResults[0].status;
                if (status === 'closed') {
                    const error = new Error('This user is already a closed account');
                    console.error(error);
                    return reject(error);
                }
                // check if user has active bids
                const bidQuery = `
                    SELECT COUNT(*) as bidCount 
                    FROM Bid 
                    JOIN Item ON Bid.item_id = Item.item_id 
                    WHERE Bid.buyer_id = ${mysql.escape(username)} 
                    AND Item.status = 'active'
                `;
                console.log('Executing bid query:', bidQuery);
                pool.query(bidQuery, (bidError, bidResults) => {
                    if (bidError) {
                        console.error('Bid query error:', bidError);
                        return reject(bidError);
                    }

                    const bidCount = bidResults[0].bidCount;
                    if (bidCount > 0) {
                        const error = new Error('You can not close an account with active bids')
                        console.error(error);
                        return reject(error);
                    }
                });
                // check if user has seller has active items
                const itemQuery = `SELECT COUNT(*) as itemCount FROM Item WHERE seller_id = ${mysql.escape(username)} AND status = 'active'`;
                console.log('Executing item query:', itemQuery);
                pool.query(itemQuery, (itemError, itemResults) => {
                    if (itemError) {
                        console.error('Bid query error:', itemError);
                        return reject(itemError);
                    }

                    const itemCount = itemResults[0].itemCount;
                    if (itemCount > 0) {
                        const error = new Error('You can not close an account with active items')
                        console.error(error);
                        return reject(error);
                    }
                });
            }

            // Proceed with making user closed
            const insertQuery = `
                INSERT INTO ${mysql.escapeId(accountType)} (username, password, status, funds)
                VALUES (${mysql.escape(username)}, ${mysql.escape(password)}, 'active', 0)
            `;
            console.log('Executing insert query:', insertQuery);
            pool.query(insertQuery, (insertError, insertResults) => {
                if (insertError) {
                    console.error('Insert query error:', insertError);
                    return reject(insertError);
                } else {
                    console.log('Insert query results:', insertResults);
                    return resolve({
                        statusCode: 200,
                        body: JSON.stringify(insertResults),
                    });
                }
            });
        });
    });
};