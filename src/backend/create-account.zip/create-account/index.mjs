import mysql from 'mysql';

export const handler = async (event) => {
    console.log('Creating MySQL pool...');
    var pool = mysql.createPool({
        host: "auctionhousedb.chyqe6cmmf08.us-east-1.rds.amazonaws.com",
        user: "auctionadmin",
        password: "sp6dO9CPdNecytAhsnQm",
        database: "auctionhouse"
    });

    const username = event.username;
    const password = event.password;
    const accountType = event.accountType;

    return new Promise((resolve, reject) => {
        // type check all args
        if (typeof username !== 'string') {
            const error = new TypeError('Invalid username parameter. Expected a string.');
            console.error(error);
            return reject(error);
        }
        if (typeof password !== 'string') {
            const error = new TypeError('Invalid password parameter. Expected a string.');
            console.error(error);
            return reject(error);
        }
        if (typeof accountType !== 'string') {
            const error = new TypeError('Invalid accountType parameter. Expected a string.');
            console.error(error);
            return reject(error);
        }
        const query = `
            INSERT INTO ${mysql.escapeId(accountType)} (username, password, status, funds)
            VALUES (${mysql.escape(username)}, ${mysql.escape(password)}, 'active', 0)
        `;
        console.log('Executing query:', query);
        pool.query(query, (error, results) => {
            if (error) {
                console.error('Query error:', error);
                reject(error);
            } else {
                console.log('Query results:', results);
                resolve({
                    statusCode: 200,
                    body: JSON.stringify(results),
                });
            }
        });
    });
};